# 📱 How to Install Spend Tracker on Android

## Method 1: Install as PWA (Progressive Web App) - RECOMMENDED ✅

This is the easiest method and works on all Android phones!

### Steps:

1. **Copy Files to Web Server**
   - You need to host these 3 files on a web server:
     - `spend-tracker.html`
     - `manifest.json`
     - `service-worker.js`

2. **Using GitHub Pages (FREE - Easiest Option)**
   
   a. Go to https://github.com and create a free account (if you don't have one)
   
   b. Create a new repository called "spend-tracker"
   
   c. Upload all 3 files (spend-tracker.html, manifest.json, service-worker.js)
   
   d. Go to Settings → Pages → Source → Select "main" branch → Save
   
   e. Your app will be live at: `https://[your-username].github.io/spend-tracker/spend-tracker.html`

3. **Install on Android Phone**
   
   a. Open the URL in **Chrome browser** on your Android phone
   
   b. You'll see an "Install App" button at the bottom of the screen
   
   c. Tap "Install" 
   
   d. The app will be added to your home screen like a native app!

4. **Alternative Install Method (if banner doesn't appear)**
   
   a. Open the page in Chrome
   
   b. Tap the **3-dot menu** (⋮) in the top right
   
   c. Tap **"Add to Home screen"** or **"Install app"**
   
   d. Tap "Add" or "Install"

---

## Method 2: Using Local Server (For Testing)

If you want to test locally before hosting:

### Option A: Using Python (if you have Python installed)

1. Put all 3 files in a folder
2. Open terminal/command prompt in that folder
3. Run: `python -m http.server 8000`
4. On your phone browser, go to: `http://[your-computer-ip]:8000/spend-tracker.html`
5. Follow install steps from Method 1

### Option B: Using Online Hosting Services (FREE)

**Netlify Drop** (Super Easy - No account needed for basic use)
1. Go to https://app.netlify.com/drop
2. Drag and drop all 3 files into the box
3. You'll get a live URL instantly
4. Open that URL on your Android phone and install!

**Vercel** (Free with account)
1. Go to https://vercel.com
2. Sign up (free)
3. Upload your files
4. Get instant live URL
5. Install on Android phone

---

## Method 3: Convert to APK (Advanced)

If you really want a traditional APK file:

### Using PWA Builder (Online Tool)

1. First, host your files using Method 1 or Method 2
2. Go to https://www.pwabuilder.com
3. Enter your hosted URL
4. Click "Start" 
5. Click "Package for Stores"
6. Choose "Android" 
7. Download the APK
8. Transfer APK to your phone
9. Enable "Install from Unknown Sources" in phone settings
10. Install the APK

### Using Android Studio (Most Complex)

This requires development knowledge and is more complex. The PWA method above is much easier and works just as well!

---

## Features of the Installed App:

✅ Works offline (after first load)
✅ Appears on home screen with app icon
✅ Full-screen experience (no browser bars)
✅ Fast loading
✅ All data stored locally on your phone
✅ Automatic notifications for fixed cost warnings

---

## Troubleshooting:

**Q: I don't see the "Install" button**
A: Make sure you're using Chrome browser and the page is loaded via HTTPS (not HTTP)

**Q: Can I use this offline?**
A: Yes! After the first load, everything works offline. Your data is stored locally.

**Q: Will I lose my data?**
A: No, all data is stored in your browser's local storage and persists even after closing the app.

**Q: Can I use this on iPhone?**
A: Yes! On iPhone, use Safari and tap the Share button → "Add to Home Screen"

---

## Recommended: GitHub Pages (100% Free & Easy)

The easiest way is to use GitHub Pages:

1. Create GitHub account
2. Create repository "spend-tracker"  
3. Upload the 3 files
4. Enable Pages in Settings
5. Visit your URL on Android Chrome
6. Tap "Install"
7. Done! 🎉

Your URL will be: `https://[username].github.io/spend-tracker/spend-tracker.html`

---

## Quick Start Summary:

📤 **Upload files** → 🌐 **Get URL** → 📱 **Open in Chrome** → ⬇️ **Install** → ✅ **Use as app!**

That's it! No coding, no APK building, no complex setup needed!
