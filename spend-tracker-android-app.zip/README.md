# 💰 Personal Spend Tracker - Android App

A powerful personal finance app to track your income, fixed costs, and expenses with smart insights and notifications.

## 📦 Package Contents

This package contains:
- `spend-tracker.html` - Main application file
- `manifest.json` - PWA configuration for Android installation
- `service-worker.js` - Offline functionality support
- `INSTALLATION_GUIDE.md` - Detailed installation instructions

## 🚀 Quick Install (3 Minutes!)

**Easiest Method - GitHub Pages (FREE):**

1. Create a free account at https://github.com
2. Create a new repository called "spend-tracker"
3. Upload all 3 files (spend-tracker.html, manifest.json, service-worker.js)
4. Go to Settings → Pages → Enable GitHub Pages
5. Your app will be live at: `https://[your-username].github.io/spend-tracker/spend-tracker.html`
6. Open that URL on your Android phone in Chrome
7. Tap "Install App" when the banner appears
8. Done! The app is now on your home screen! 🎉

**Alternative - Netlify Drop (Even Faster!):**

1. Go to https://app.netlify.com/drop
2. Drag all 3 files into the upload box
3. Get instant URL
4. Open on Android Chrome → Install
5. Done!

## ✨ Features

- 📊 Track income and fixed monthly costs
- 💸 Record all expenses by category
- 🔔 Smart notifications when fixed costs approach/exceed 70%
- 📈 Visual charts and spending trends
- 💡 AI-powered spending insights
- 📅 Monthly reports and analysis
- 💾 Export data to CSV/JSON
- 📱 Works offline after first load
- 🔒 All data stored locally on your device

## 📱 Works On

- ✅ Android phones (Chrome browser)
- ✅ iPhones (Safari browser)
- ✅ Tablets
- ✅ Desktop computers

## 🔐 Privacy

- All data is stored locally on YOUR device only
- No data is sent to any server
- No tracking, no analytics
- 100% private and secure

## 📖 Full Documentation

See `INSTALLATION_GUIDE.md` for detailed installation instructions and troubleshooting.

## 💬 Support

If you need help:
1. Read the INSTALLATION_GUIDE.md
2. Make sure you're using Chrome on Android
3. Ensure the page is loaded via HTTPS

---

**Enjoy tracking your finances! 💰📊**
